package com.ibnu.artalele.ui.hutang.tambah

interface TambahHutangHandler {
    fun onSuccess()
    fun onFailed(message: String)
}