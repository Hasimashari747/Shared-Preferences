package com.ibnu.artalele.utils

interface RecyclerviewItemClickHandler {
    fun onClickItem(id: Int)
}